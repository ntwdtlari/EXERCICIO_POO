public class Main {
    public static void main(String[] args) {
        Livro livro1 = new Livro("O Pequeno Príncipe", 29.90, "Antoine de Saint-Exupéry", 96, false);
        Camisa camisa1 = new Camisa("Camisa Branca", 49.90, "Branco", "G", "Algodão");

        System.out.println("Informações do Livro:");
        livro1.exibirInfo();

        System.out.println("\nInformações da Camisa:");
        camisa1.exibirInfo();
    }
}